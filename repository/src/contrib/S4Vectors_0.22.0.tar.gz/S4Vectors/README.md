[<img src="https://www.bioconductor.org/images/logo/jpg/bioconductor_logo_rgb.jpg" width="200" align="right"/>](https://bioconductor.org/)

_S4Vectors_ is an R/Bioconductor package that provides the foundation of vector-like and list-like containers in Bioconductor.

See https://bioconductor.org/packages/S4Vectors for more information including how to install the release version of the package (please refrain from installing directly from GitHub).

