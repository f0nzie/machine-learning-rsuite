### R code from vignette source 'BiostringsQuickOverview.Rnw'
### Encoding: UTF-8

